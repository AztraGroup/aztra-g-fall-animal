# Changelog

Todas as mudanças notáveis deste projeto serão documentadas neste arquivo.

## [Unreleased]

- Document installation via `.zip`, generated pages, shortcodes/REST routes, translation and accessibility guidance
- Note build command `zip -r aztra-g.zip .`

## [1.2.0] - 2025-08-17
- Versão inicial.
